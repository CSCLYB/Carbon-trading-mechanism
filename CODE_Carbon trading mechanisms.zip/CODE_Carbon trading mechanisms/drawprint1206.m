Yzep1 =[oo_.irfs.Y_ep1]; 
Yyep1 =[oo_.irfs.Y1_ep1]; 
Yeep1 =[oo_.irfs.Y2_ep1]; 
Czep1 =[oo_.irfs.C_ep1]; 
Cyep1 =[oo_.irfs.C1_ep1]; 
Ceep1 =[oo_.irfs.C2_ep1]; 
Izep1 =[oo_.irfs.I_ep1]; 
Iyep1 =[oo_.irfs.I1_ep1]; 
Ieep1 =[oo_.irfs.I2_ep1]; 

Yzep2 =[oo_.irfs.Y_ep2]; 
Yyep2 =[oo_.irfs.Y1_ep2]; 
Yeep2 =[oo_.irfs.Y2_ep2]; 
Czep2 =[oo_.irfs.C_ep2]; 
Cyep2 =[oo_.irfs.C1_ep2]; 
Ceep2 =[oo_.irfs.C2_ep2]; 
Izep2 =[oo_.irfs.I_ep2]; 
Iyep2 =[oo_.irfs.I1_ep2]; 
Ieep2 =[oo_.irfs.I2_ep2]; 

% 创建主图对象
figure;
% 切换到第一个子图
subplot(3,3,1);
x = linspace(0,30,30);
Yzep1 =[oo_.irfs.Y_ep1]; 
plot(x,Yzep1,'-k')
title('Combine Plots')
hold on
Yzep2 =[oo_.irfs.Y_ep2]; 
plot(x,Yzep2,'--k*')
hold off
% 切换到第二个子图
subplot(3,3,2); 
x = linspace(0,30,30);
Yyep1=[oo_.irfs.Y1_ep1]; 
plot(x,Yyep1,'-k')
title('Combine Plots')
hold on
Yyep2 =[oo_.irfs.Y1_ep2]; 
plot(x,Yyep2,'--k*')
hold off
% 切换到第三个子图
subplot(3,3,3);
x = linspace(0,30,30);
Yeep1 =[oo_.irfs.Y2_ep1]; 
plot(x,Yzep1,'-k')
title('Combine Plots')
hold on
Yzep2 =[oo_.irfs.Y_ep2]; 
plot(x,Yzep2,'--k*')
hold off
% 切换到第四个子图
subplot(3,3,4); 
x = linspace(0,30,30);
Yyep1=[oo_.irfs.Y1_ep1]; 
plot(x,Yyep1,'-k')
title('Combine Plots')
hold on
Yyep2 =[oo_.irfs.Y1_ep2]; 
plot(x,Yyep2,'--k*')
hold off
% 切换到第五个子图
subplot(3,3,1);
x = linspace(0,30,30);
Yzep1 =[oo_.irfs.Y_ep1]; 
plot(x,Yzep1,'-k')
title('Combine Plots')
hold on
Yzep2 =[oo_.irfs.Y_ep2]; 
plot(x,Yzep2,'--k*')
hold off
% 切换到第六个子图
subplot(3,3,2); 
x = linspace(0,30,30);
Yyep1=[oo_.irfs.Y1_ep1]; 
plot(x,Yyep1,'-k')
title('Combine Plots')
hold on
Yyep2 =[oo_.irfs.Y1_ep2]; 
plot(x,Yyep2,'--k*')
hold off
% 切换到第七个子图
subplot(3,3,1);
x = linspace(0,30,30);
Yzep1 =[oo_.irfs.Y_ep1]; 
plot(x,Yzep1,'-k')
title('Combine Plots')
hold on
Yzep2 =[oo_.irfs.Y_ep2]; 
plot(x,Yzep2,'--k*')
hold off
% 切换到第八个子图
subplot(3,3,2); 
x = linspace(0,30,30);
Yyep1=[oo_.irfs.Y1_ep1]; 
plot(x,Yyep1,'-k')
title('Combine Plots')
hold on
Yyep2 =[oo_.irfs.Y1_ep2]; 
plot(x,Yyep2,'--k*')
hold off
% 切换到第九个子图
subplot(3,3,1);
x = linspace(0,30,30);
Yzep1 =[oo_.irfs.Y_ep1]; 
plot(x,Yzep1,'-k')
title('Combine Plots')
hold on
Yzep2 =[oo_.irfs.Y_ep2]; 
plot(x,Yzep2,'--k*')
hold off
