function residual = dynamic_resid(T, y, x, params, steady_state, it_, T_flag)
% function residual = dynamic_resid(T, y, x, params, steady_state, it_, T_flag)
%
% File created by Dynare Preprocessor from .mod file
%
% Inputs:
%   T             [#temp variables by 1]     double   vector of temporary terms to be filled by function
%   y             [#dynamic variables by 1]  double   vector of endogenous variables in the order stored
%                                                     in M_.lead_lag_incidence; see the Manual
%   x             [nperiods by M_.exo_nbr]   double   matrix of exogenous variables (in declaration order)
%                                                     for all simulation periods
%   steady_state  [M_.endo_nbr by 1]         double   vector of steady state values
%   params        [M_.param_nbr by 1]        double   vector of parameter values in declaration order
%   it_           scalar                     double   time period for exogenous variables for which
%                                                     to evaluate the model
%   T_flag        boolean                    boolean  flag saying whether or not to calculate temporary terms
%
% Output:
%   residual
%

if T_flag
    T = nov1116jiapaifang.dynamic_resid_tt(T, y, x, params, steady_state, it_);
end
residual = zeros(54, 1);
lhs = exp(y(20));
rhs = params(6)/T(3)/(1-params(5));
residual(1) = lhs - rhs;
lhs = exp(y(22));
rhs = params(7)/T(3)/(1-params(5));
residual(2) = lhs - rhs;
lhs = exp(y(24));
rhs = (T(7)-(1-params(12)))/(1-params(5));
residual(3) = lhs - rhs;
lhs = exp(y(28));
rhs = (T(7)-(1-params(11)))/(1-params(5));
residual(4) = lhs - rhs;
lhs = exp(y(26));
rhs = (1-params(12))*exp(y(3))+exp(y(32));
residual(5) = lhs - rhs;
lhs = exp(y(30));
rhs = (1-params(11))*exp(y(5))+exp(y(34));
residual(6) = lhs - rhs;
lhs = exp(y(21));
rhs = params(8)/T(10)/(1-params(5));
residual(7) = lhs - rhs;
lhs = exp(y(23));
rhs = params(9)/T(10)/(1-params(5));
residual(8) = lhs - rhs;
lhs = exp(y(25));
rhs = (T(14)-(1-params(12)))/(1-params(5));
residual(9) = lhs - rhs;
lhs = exp(y(29));
rhs = (T(14)-(1-params(11)))/(1-params(5));
residual(10) = lhs - rhs;
lhs = exp(y(27));
rhs = (1-params(12))*exp(y(4))+exp(y(33));
residual(11) = lhs - rhs;
lhs = exp(y(31));
rhs = (1-params(11))*exp(y(6))+exp(y(35));
residual(12) = lhs - rhs;
lhs = exp(y(50));
rhs = T(15)^T(16);
residual(13) = lhs - rhs;
lhs = exp(y(40));
rhs = params(13)*T(17)^(params(14)-1);
residual(14) = lhs - rhs;
lhs = exp(y(41));
rhs = (1-params(13))*T(18)^(params(14)-1);
residual(15) = lhs - rhs;
lhs = exp(y(51));
rhs = T(19)^T(16);
residual(16) = lhs - rhs;
lhs = exp(y(40));
rhs = (1-params(13))*T(20)^(params(14)-1);
residual(17) = lhs - rhs;
lhs = exp(y(41));
rhs = params(13)*T(21)^(params(14)-1);
residual(18) = lhs - rhs;
lhs = exp(y(42));
rhs = T(28)*T(29);
residual(19) = lhs - rhs;
lhs = exp(y(24));
rhs = exp(y(42))*exp(y(40))*params(20)/exp(y(26));
residual(20) = lhs - rhs;
lhs = exp(y(20));
rhs = T(30);
residual(21) = lhs - rhs;
lhs = exp(y(48));
rhs = exp(y(42))*exp(y(40))*params(2)/exp(y(46));
residual(22) = lhs - rhs;
lhs = exp(y(55));
rhs = T(32)*T(33);
residual(23) = lhs - rhs;
lhs = exp(y(46));
rhs = exp(y(55))*params(18);
residual(24) = lhs - rhs;
lhs = exp(y(28));
rhs = exp(y(55))*exp(y(48))*params(21)*params(18)/exp(y(30));
residual(25) = lhs - rhs;
lhs = exp(y(22));
rhs = T(34);
residual(26) = lhs - rhs;
lhs = exp(y(43));
rhs = T(41)*T(42);
residual(27) = lhs - rhs;
lhs = exp(y(25));
rhs = exp(y(43))*exp(y(41))*params(22)/exp(y(27));
residual(28) = lhs - rhs;
lhs = exp(y(21));
rhs = T(43);
residual(29) = lhs - rhs;
lhs = exp(y(49));
rhs = exp(y(43))*exp(y(41))*params(3)/exp(y(47));
residual(30) = lhs - rhs;
lhs = exp(y(56));
rhs = T(45)*T(46);
residual(31) = lhs - rhs;
lhs = exp(y(47));
rhs = exp(y(56))*params(19);
residual(32) = lhs - rhs;
lhs = exp(y(29));
rhs = exp(y(56))*exp(y(49))*params(23)*params(19)/exp(y(31));
residual(33) = lhs - rhs;
lhs = exp(y(23));
rhs = T(47);
residual(34) = lhs - rhs;
lhs = exp(y(53));
rhs = exp(y(14))+exp(y(44))+exp(y(34))+exp(y(12))+exp(y(32))+exp(y(40))*exp(y(37))-exp(y(38))*exp(y(41));
residual(35) = lhs - rhs;
lhs = exp(y(53));
rhs = exp(y(40))*exp(y(42));
residual(36) = lhs - rhs;
lhs = exp(y(42));
rhs = exp(y(36))+exp(y(37));
residual(37) = lhs - rhs;
lhs = exp(y(54));
rhs = exp(y(38))*exp(y(41))+exp(y(15))+exp(y(45))+exp(y(35))+exp(y(13))+exp(y(33))-exp(y(40))*exp(y(37));
residual(38) = lhs - rhs;
lhs = exp(y(54));
rhs = exp(y(41))*exp(y(43));
residual(39) = lhs - rhs;
lhs = exp(y(43));
rhs = exp(y(38))+exp(y(39));
residual(40) = lhs - rhs;
lhs = y(52);
rhs = params(28)*y(9)+(1-params(28))*params(75)+x(it_, 1);
residual(41) = lhs - rhs;
lhs = log(exp(y(14))/exp(y(53)*params(17)));
rhs = params(31)*log(exp(y(1))/exp(params(17)*y(10)))+x(it_, 4);
residual(42) = lhs - rhs;
lhs = log(exp(y(15))/exp(y(54)*params(17)));
rhs = params(32)*log(exp(y(2))/exp(params(17)*y(11)))+x(it_, 5);
residual(43) = lhs - rhs;
lhs = log(exp(y(44))/exp(y(53)+log(params(16))));
rhs = params(29)*log(exp(y(7))/exp(y(10)+log(params(16))))-params(26)*(min(y(53)-y(54),0)+max(y(46)-y(47),0))+params(27)*(max(y(53)-y(54),0)+min(y(46)-y(47),0))+x(it_, 2);
residual(44) = lhs - rhs;
lhs = log(exp(y(45))/exp(y(54)+log(params(16))));
rhs = params(30)*log(exp(y(8))/exp(y(11)+log(params(16))))-params(26)*(min(y(54)-y(53),0)+max(y(47)-y(46),0))+params(27)*(max(y(54)-y(53),0)+min(y(47)-y(46),0))+x(it_, 3);
residual(45) = lhs - rhs;
lhs = exp(y(57));
rhs = exp(y(53))+exp(y(54));
residual(46) = lhs - rhs;
lhs = exp(y(59));
rhs = exp(y(32))+exp(y(34));
residual(47) = lhs - rhs;
lhs = exp(y(60));
rhs = exp(y(33))+exp(y(35));
residual(48) = lhs - rhs;
lhs = exp(y(58));
rhs = exp(y(35))+exp(y(33))+exp(y(32))+exp(y(34));
residual(49) = lhs - rhs;
lhs = exp(y(61));
rhs = exp(y(12))+exp(y(13));
residual(50) = lhs - rhs;
lhs = y(62);
rhs = y(53)-y(54);
residual(51) = lhs - rhs;
lhs = exp(y(64));
rhs = exp(y(46))*(1/params(24)-1);
residual(52) = lhs - rhs;
lhs = exp(y(65));
rhs = exp(y(47))*(1/params(25)-1);
residual(53) = lhs - rhs;
lhs = exp(y(63));
rhs = exp(y(64))+exp(y(65));
residual(54) = lhs - rhs;

end
