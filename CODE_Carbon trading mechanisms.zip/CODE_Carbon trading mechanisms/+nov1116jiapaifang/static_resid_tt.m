function T = static_resid_tt(T, y, x, params)
% function T = static_resid_tt(T, y, x, params)
%
% File created by Dynare Preprocessor from .mod file
%
% Inputs:
%   T         [#temp variables by 1]  double   vector of temporary terms to be filled by function
%   y         [M_.endo_nbr by 1]      double   vector of endogenous variables in declaration order
%   x         [M_.exo_nbr by 1]       double   vector of exogenous variables in declaration order
%   params    [M_.param_nbr by 1]     double   vector of parameter values in declaration order
%
% Output:
%   T         [#temp variables by 1]  double   vector of temporary terms
%

assert(length(T) >= 43);

T(1) = exp(y(1))^(-params(10));
T(2) = exp(y(3))^(params(4)*(1-params(10)));
T(3) = T(1)*T(2);
T(4) = (1/params(1)-(1-params(12)))/(1-params(5));
T(5) = (1/params(1)-(1-params(11)))/(1-params(5));
T(6) = exp(y(2))^(-params(10));
T(7) = exp(y(4))^(params(4)*(1-params(10)));
T(8) = T(6)*T(7);
T(9) = params(13)*exp(y(25))^params(14)+(1-params(13))*exp(y(27))^params(14);
T(10) = 1/params(14);
T(11) = exp(y(25))/exp(y(39));
T(12) = exp(y(27))/exp(y(39));
T(13) = (1-params(13))*exp(y(26))^params(14)+params(13)*exp(y(28))^params(14);
T(14) = exp(y(26))/exp(y(40));
T(15) = exp(y(28))/exp(y(40));
T(16) = (1/params(24))^params(2);
T(17) = y(41)*T(16);
T(18) = exp(y(33))^params(15);
T(19) = T(17)*T(18);
T(20) = exp(y(15))^params(20);
T(21) = exp(y(35))^params(2);
T(22) = T(19)*T(20)*T(21);
T(23) = exp(y(5))^(1-params(20)-params(2));
T(24) = exp(y(31))*exp(y(29))*(1-params(20)-params(2))/exp(y(5));
T(25) = exp(y(19))^params(21);
T(26) = y(41)*T(25);
T(27) = exp(y(7))^(1-params(21));
T(28) = exp(y(44))*exp(y(37))*(1-params(21))*params(18)/exp(y(7));
T(29) = (1/params(25))^params(3);
T(30) = y(41)*T(29);
T(31) = exp(y(34))^params(15);
T(32) = T(30)*T(31);
T(33) = exp(y(16))^params(22);
T(34) = exp(y(36))^params(3);
T(35) = T(32)*T(33)*T(34);
T(36) = exp(y(6))^(1-params(22)-params(3));
T(37) = exp(y(32))*exp(y(30))*(1-params(22)-params(3))/exp(y(6));
T(38) = exp(y(20))^params(23);
T(39) = y(41)*T(38);
T(40) = exp(y(8))^(1-params(23));
T(41) = exp(y(45))*exp(y(38))*(1-params(23))*params(19)/exp(y(8));
T(42) = log(exp(y(33))/exp(y(42)+log(params(16))));
T(43) = log(exp(y(34))/exp(y(43)+log(params(16))));

end
