function residual = static_resid(T, y, x, params, T_flag)
% function residual = static_resid(T, y, x, params, T_flag)
%
% File created by Dynare Preprocessor from .mod file
%
% Inputs:
%   T         [#temp variables by 1]  double   vector of temporary terms to be filled by function
%   y         [M_.endo_nbr by 1]      double   vector of endogenous variables in declaration order
%   x         [M_.exo_nbr by 1]       double   vector of exogenous variables in declaration order
%   params    [M_.param_nbr by 1]     double   vector of parameter values in declaration order
%                                              to evaluate the model
%   T_flag    boolean                 boolean  flag saying whether or not to calculate temporary terms
%
% Output:
%   residual
%

if T_flag
    T = nov1116jiapaifang.static_resid_tt(T, y, x, params);
end
residual = zeros(54, 1);
lhs = exp(y(9));
rhs = params(6)/T(3)/(1-params(5));
residual(1) = lhs - rhs;
lhs = exp(y(11));
rhs = params(7)/T(3)/(1-params(5));
residual(2) = lhs - rhs;
lhs = exp(y(13));
rhs = T(4);
residual(3) = lhs - rhs;
lhs = exp(y(17));
rhs = T(5);
residual(4) = lhs - rhs;
lhs = exp(y(15));
rhs = (1-params(12))*exp(y(15))+exp(y(21));
residual(5) = lhs - rhs;
lhs = exp(y(19));
rhs = (1-params(11))*exp(y(19))+exp(y(23));
residual(6) = lhs - rhs;
lhs = exp(y(10));
rhs = params(8)/T(8)/(1-params(5));
residual(7) = lhs - rhs;
lhs = exp(y(12));
rhs = params(9)/T(8)/(1-params(5));
residual(8) = lhs - rhs;
lhs = exp(y(14));
rhs = T(4);
residual(9) = lhs - rhs;
lhs = exp(y(18));
rhs = T(5);
residual(10) = lhs - rhs;
lhs = exp(y(16));
rhs = (1-params(12))*exp(y(16))+exp(y(22));
residual(11) = lhs - rhs;
lhs = exp(y(20));
rhs = (1-params(11))*exp(y(20))+exp(y(24));
residual(12) = lhs - rhs;
lhs = exp(y(39));
rhs = T(9)^T(10);
residual(13) = lhs - rhs;
lhs = exp(y(29));
rhs = params(13)*T(11)^(params(14)-1);
residual(14) = lhs - rhs;
lhs = exp(y(30));
rhs = (1-params(13))*T(12)^(params(14)-1);
residual(15) = lhs - rhs;
lhs = exp(y(40));
rhs = T(13)^T(10);
residual(16) = lhs - rhs;
lhs = exp(y(29));
rhs = (1-params(13))*T(14)^(params(14)-1);
residual(17) = lhs - rhs;
lhs = exp(y(30));
rhs = params(13)*T(15)^(params(14)-1);
residual(18) = lhs - rhs;
lhs = exp(y(31));
rhs = T(22)*T(23);
residual(19) = lhs - rhs;
lhs = exp(y(13));
rhs = exp(y(31))*exp(y(29))*params(20)/exp(y(15));
residual(20) = lhs - rhs;
lhs = exp(y(9));
rhs = T(24);
residual(21) = lhs - rhs;
lhs = exp(y(37));
rhs = exp(y(31))*exp(y(29))*params(2)/exp(y(35));
residual(22) = lhs - rhs;
lhs = exp(y(44));
rhs = T(26)*T(27);
residual(23) = lhs - rhs;
lhs = exp(y(35));
rhs = exp(y(44))*params(18);
residual(24) = lhs - rhs;
lhs = exp(y(17));
rhs = exp(y(44))*exp(y(37))*params(21)*params(18)/exp(y(19));
residual(25) = lhs - rhs;
lhs = exp(y(11));
rhs = T(28);
residual(26) = lhs - rhs;
lhs = exp(y(32));
rhs = T(35)*T(36);
residual(27) = lhs - rhs;
lhs = exp(y(14));
rhs = exp(y(32))*exp(y(30))*params(22)/exp(y(16));
residual(28) = lhs - rhs;
lhs = exp(y(10));
rhs = T(37);
residual(29) = lhs - rhs;
lhs = exp(y(38));
rhs = exp(y(32))*exp(y(30))*params(3)/exp(y(36));
residual(30) = lhs - rhs;
lhs = exp(y(45));
rhs = T(39)*T(40);
residual(31) = lhs - rhs;
lhs = exp(y(36));
rhs = exp(y(45))*params(19);
residual(32) = lhs - rhs;
lhs = exp(y(18));
rhs = exp(y(45))*exp(y(38))*params(23)*params(19)/exp(y(20));
residual(33) = lhs - rhs;
lhs = exp(y(12));
rhs = T(41);
residual(34) = lhs - rhs;
lhs = exp(y(42));
rhs = exp(y(3))+exp(y(33))+exp(y(23))+exp(y(1))+exp(y(21))+exp(y(29))*exp(y(26))-exp(y(27))*exp(y(30));
residual(35) = lhs - rhs;
lhs = exp(y(42));
rhs = exp(y(29))*exp(y(31));
residual(36) = lhs - rhs;
lhs = exp(y(31));
rhs = exp(y(25))+exp(y(26));
residual(37) = lhs - rhs;
lhs = exp(y(43));
rhs = exp(y(27))*exp(y(30))+exp(y(4))+exp(y(34))+exp(y(24))+exp(y(2))+exp(y(22))-exp(y(29))*exp(y(26));
residual(38) = lhs - rhs;
lhs = exp(y(43));
rhs = exp(y(30))*exp(y(32));
residual(39) = lhs - rhs;
lhs = exp(y(32));
rhs = exp(y(27))+exp(y(28));
residual(40) = lhs - rhs;
lhs = y(41);
rhs = y(41)*params(28)+(1-params(28))*params(75)+x(1);
residual(41) = lhs - rhs;
lhs = log(exp(y(3))/exp(y(42)*params(17)));
rhs = log(exp(y(3))/exp(y(42)*params(17)))*params(31)+x(4);
residual(42) = lhs - rhs;
lhs = log(exp(y(4))/exp(y(43)*params(17)));
rhs = log(exp(y(4))/exp(y(43)*params(17)))*params(32)+x(5);
residual(43) = lhs - rhs;
lhs = T(42);
rhs = T(42)*params(29)-params(26)*(min(y(42)-y(43),0)+max(y(35)-y(36),0))+params(27)*(max(y(42)-y(43),0)+min(y(35)-y(36),0))+x(2);
residual(44) = lhs - rhs;
lhs = T(43);
rhs = T(43)*params(30)-params(26)*(min(y(43)-y(42),0)+max(y(36)-y(35),0))+params(27)*(max(y(43)-y(42),0)+min(y(36)-y(35),0))+x(3);
residual(45) = lhs - rhs;
lhs = exp(y(46));
rhs = exp(y(42))+exp(y(43));
residual(46) = lhs - rhs;
lhs = exp(y(48));
rhs = exp(y(21))+exp(y(23));
residual(47) = lhs - rhs;
lhs = exp(y(49));
rhs = exp(y(22))+exp(y(24));
residual(48) = lhs - rhs;
lhs = exp(y(47));
rhs = exp(y(24))+exp(y(22))+exp(y(21))+exp(y(23));
residual(49) = lhs - rhs;
lhs = exp(y(50));
rhs = exp(y(1))+exp(y(2));
residual(50) = lhs - rhs;
lhs = y(51);
rhs = y(42)-y(43);
residual(51) = lhs - rhs;
lhs = exp(y(53));
rhs = exp(y(35))*(1/params(24)-1);
residual(52) = lhs - rhs;
lhs = exp(y(54));
rhs = exp(y(36))*(1/params(25)-1);
residual(53) = lhs - rhs;
lhs = exp(y(52));
rhs = exp(y(53))+exp(y(54));
residual(54) = lhs - rhs;
if ~isreal(residual)
  residual = real(residual)+imag(residual).^2;
end
end
