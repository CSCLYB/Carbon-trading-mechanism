function T = dynamic_g1_tt(T, y, x, params, steady_state, it_)
% function T = dynamic_g1_tt(T, y, x, params, steady_state, it_)
%
% File created by Dynare Preprocessor from .mod file
%
% Inputs:
%   T             [#temp variables by 1]     double  vector of temporary terms to be filled by function
%   y             [#dynamic variables by 1]  double  vector of endogenous variables in the order stored
%                                                    in M_.lead_lag_incidence; see the Manual
%   x             [nperiods by M_.exo_nbr]   double  matrix of exogenous variables (in declaration order)
%                                                    for all simulation periods
%   steady_state  [M_.endo_nbr by 1]         double  vector of steady state values
%   params        [M_.param_nbr by 1]        double  vector of parameter values in declaration order
%   it_           scalar                     double  time period for exogenous variables for which
%                                                    to evaluate the model
%
% Output:
%   T           [#temp variables by 1]       double  vector of temporary terms
%

assert(length(T) >= 67);

T = nov1116jiapaifang.dynamic_resid_tt(T, y, x, params, steady_state, it_);

T(48) = T(2)*exp(y(12))*getPowerDeriv(exp(y(12)),(-params(10)),1);
T(49) = (-(T(48)/T(6)/params(1)/(1-params(5))));
T(50) = (-((-(T(3)*T(5)*exp(y(66))*getPowerDeriv(exp(y(66)),(-params(10)),1)))/(T(6)*T(6))/params(1)/(1-params(5))));
T(51) = T(9)*exp(y(13))*getPowerDeriv(exp(y(13)),(-params(10)),1);
T(52) = (-(T(51)/T(13)/params(1)/(1-params(5))));
T(53) = (-((-(T(10)*T(12)*exp(y(67))*getPowerDeriv(exp(y(67)),(-params(10)),1)))/(T(13)*T(13))/params(1)/(1-params(5))));
T(54) = T(1)*exp(y(14))*getPowerDeriv(exp(y(14)),params(4)*(1-params(10)),1);
T(55) = (-(T(54)/T(6)/params(1)/(1-params(5))));
T(56) = (-((-(T(3)*T(4)*exp(y(68))*getPowerDeriv(exp(y(68)),params(4)*(1-params(10)),1)))/(T(6)*T(6))/params(1)/(1-params(5))));
T(57) = T(8)*exp(y(15))*getPowerDeriv(exp(y(15)),params(4)*(1-params(10)),1);
T(58) = (-(T(57)/T(13)/params(1)/(1-params(5))));
T(59) = (-((-(T(10)*T(11)*exp(y(69))*getPowerDeriv(exp(y(69)),params(4)*(1-params(10)),1)))/(T(13)*T(13))/params(1)/(1-params(5))));
T(60) = getPowerDeriv(T(15),T(16),1);
T(61) = getPowerDeriv(T(17),params(14)-1,1);
T(62) = getPowerDeriv(T(19),T(16),1);
T(63) = getPowerDeriv(T(20),params(14)-1,1);
T(64) = getPowerDeriv(T(18),params(14)-1,1);
T(65) = getPowerDeriv(T(21),params(14)-1,1);
T(66) = (-(exp(y(55))*exp(y(48))*params(21)*params(18)/exp(y(30))));
T(67) = (-(exp(y(56))*exp(y(49))*params(23)*params(19)/exp(y(31))));

end
