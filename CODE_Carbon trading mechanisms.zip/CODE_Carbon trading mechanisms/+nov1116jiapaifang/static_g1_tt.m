function T = static_g1_tt(T, y, x, params)
% function T = static_g1_tt(T, y, x, params)
%
% File created by Dynare Preprocessor from .mod file
%
% Inputs:
%   T         [#temp variables by 1]  double   vector of temporary terms to be filled by function
%   y         [M_.endo_nbr by 1]      double   vector of endogenous variables in declaration order
%   x         [M_.exo_nbr by 1]       double   vector of exogenous variables in declaration order
%   params    [M_.param_nbr by 1]     double   vector of parameter values in declaration order
%
% Output:
%   T         [#temp variables by 1]  double   vector of temporary terms
%

assert(length(T) >= 59);

T = nov1116jiapaifang.static_resid_tt(T, y, x, params);

T(44) = T(2)*exp(y(1))*getPowerDeriv(exp(y(1)),(-params(10)),1);
T(45) = T(7)*exp(y(2))*getPowerDeriv(exp(y(2)),(-params(10)),1);
T(46) = T(1)*exp(y(3))*getPowerDeriv(exp(y(3)),params(4)*(1-params(10)),1);
T(47) = T(6)*exp(y(4))*getPowerDeriv(exp(y(4)),params(4)*(1-params(10)),1);
T(48) = getPowerDeriv(T(9),T(10),1);
T(49) = getPowerDeriv(T(11),params(14)-1,1);
T(50) = getPowerDeriv(T(13),T(10),1);
T(51) = getPowerDeriv(T(14),params(14)-1,1);
T(52) = getPowerDeriv(T(12),params(14)-1,1);
T(53) = getPowerDeriv(T(15),params(14)-1,1);
T(54) = (-(exp(y(44))*exp(y(37))*params(21)*params(18)/exp(y(19))));
T(55) = (-(exp(y(45))*exp(y(38))*params(23)*params(19)/exp(y(20))));
T(56) = (-(exp(y(3))*params(17)*exp(y(42)*params(17))))/(exp(y(42)*params(17))*exp(y(42)*params(17)))/(exp(y(3))/exp(y(42)*params(17)));
T(57) = (-(exp(y(33))*exp(y(42)+log(params(16)))))/(exp(y(42)+log(params(16)))*exp(y(42)+log(params(16))))/(exp(y(33))/exp(y(42)+log(params(16))));
T(58) = (-(exp(y(4))*params(17)*exp(y(43)*params(17))))/(exp(y(43)*params(17))*exp(y(43)*params(17)))/(exp(y(4))/exp(y(43)*params(17)));
T(59) = (-(exp(y(34))*exp(y(43)+log(params(16)))))/(exp(y(43)+log(params(16)))*exp(y(43)+log(params(16))))/(exp(y(34))/exp(y(43)+log(params(16))));

end
