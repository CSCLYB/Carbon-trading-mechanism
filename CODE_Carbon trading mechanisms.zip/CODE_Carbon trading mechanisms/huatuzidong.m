%% 发达地区和欠发达地区地方政府投资冲击对地区经济的动态影响（不考虑碳交易机制和地方政府竞争+ep1、ep2）
Size1 = [oo_.irfs.Y_ep1 , oo_.irfs.Y_ep2
        oo_.irfs.Y1_ep1, oo_.irfs.Y1_ep2
        oo_.irfs.Y2_ep1, oo_.irfs.Y2_ep2
        oo_.irfs.C_ep1 , oo_.irfs.C_ep2
        oo_.irfs.C1_ep1, oo_.irfs.C1_ep2
        oo_.irfs.C2_ep1, oo_.irfs.C2_ep2
        oo_.irfs.I_ep1 , oo_.irfs.I_ep2
        oo_.irfs.I1_ep1, oo_.irfs.I1_ep2
        oo_.irfs.I2_ep1, oo_.irfs.I2_ep2
        oo_.irfs.Emi_ep1 , oo_.irfs.Emi_ep2
        oo_.irfs.Emi1_ep1, oo_.irfs.Emi1_ep2
        oo_.irfs.Emi2_ep1, oo_.irfs.Emi2_ep2
        ];
    
figure;
for i = [1:12]
% 切换到第一个子图
subplot(4,3,i);
x = linspace(0,30,30); 
y1 = Size1(i,1:30);
plot(x,y1,'LineWidth',1 ,'color',[0.6 0.8 1])
hold on
y2 = Size1(i,31:end);
plot(x,y2, 'LineWidth',1,'color',[255 182 193]/255)
hold off
chr = 'Developed Regions'
chr1 = 'Less Developed Regions'
legend({chr,chr1},'Location','southwest')
end

%% 碳交易机制对地区经济的动态影响（基础模型+碳交易机制+ep1）
Size211116 = [oo_.irfs.Y_ea
        oo_.irfs.Y1_ea
        oo_.irfs.Y2_ea
        oo_.irfs.C_ea
        oo_.irfs.C1_ea
        oo_.irfs.C2_ea
        oo_.irfs.I_ea
        oo_.irfs.I1_ea
        oo_.irfs.I2_ea
        oo_.irfs.Emi_ea
        oo_.irfs.Emi1_ea
        oo_.irfs.Emi2_ea
        ];
 Size21119 = [oo_.irfs.Y_ea
        oo_.irfs.Y1_ea
        oo_.irfs.Y2_ea 
        oo_.irfs.C_ea
        oo_.irfs.C1_ea
        oo_.irfs.C2_ea
        oo_.irfs.I_ea
        oo_.irfs.I1_ea
        oo_.irfs.I2_ea
        oo_.irfs.Emi_ea
        oo_.irfs.Emi1_ea
        oo_.irfs.Emi2_ea
        ];
    
figure;
for i = [1:12]
% 切换到第一个子图
subplot(4,3,i);
x = linspace(0,30,30); 
y1 = Size211116(i,:);
plot(x,y1,'LineWidth',1 ,'color',[0.6 0.8 1])
hold on
y2 = Size21119(i,:);
plot(x,y2,'LineWidth',1,'color',[255 182 193]/255)
hold off
chr = 'Independent'
chr1 = 'Unite'
legend({chr,chr1},'Location','southwest')
end


%% 碳交易机制与经济、环保双重考核下地方政府投资冲击的动态响应（基础模型+碳交易机制+地方竞争+ep1/ep2）
% 地区一和地区二公共投资对总产出、地区一产出、地区二产出在四个竞争系数下的表现
 Size31119y1 = [oo_.irfs.Y_ep1,
                oo_.irfs.Y1_ep1, 
                oo_.irfs.Y2_ep1,
                oo_.irfs.Y_ep2 ,
                oo_.irfs.Y1_ep2,
                oo_.irfs.Y2_ep2
               ];
 Size31119y2 = [oo_.irfs.Y_ep1,
                oo_.irfs.Y1_ep1, 
                oo_.irfs.Y2_ep1,
                oo_.irfs.Y_ep2 ,
                oo_.irfs.Y1_ep2,
                oo_.irfs.Y2_ep2
               ];
 Size31119y3 = [oo_.irfs.Y_ep1,
                oo_.irfs.Y1_ep1, 
                oo_.irfs.Y2_ep1,
                oo_.irfs.Y_ep2 ,
                oo_.irfs.Y1_ep2,
                oo_.irfs.Y2_ep2
                ];
 Size31119y4 = [oo_.irfs.Y_ep1,
                oo_.irfs.Y1_ep1, 
                oo_.irfs.Y2_ep1,
                oo_.irfs.Y_ep2 ,
                oo_.irfs.Y1_ep2,
                oo_.irfs.Y2_ep2
                ];
% 画图（应为两个，一行三列）
figure;
for i = [1:6]
% 切换到第一个子图
subplot(2,3,i);
x = linspace(1,8,8); 
y1 = Size31119y1(i,1:8);
plot(x,y1,'-k')
hold on
y2 = Size31119y2(i,1:8);
plot(x,y2,'color',[0.6 0.8 1])
y3 = Size31119y3(i,1:8);
plot(x,y3,'color',[0 0 1])
y4 = Size31119y4(i,1:8);
plot(x,y4,'color',[1 0 1])
hold off
legend({'\psi^{1}=0','\psi^{1}=1','\psi^{1}=1.5','\psi^{1}=3'},'Location','southwest')
end