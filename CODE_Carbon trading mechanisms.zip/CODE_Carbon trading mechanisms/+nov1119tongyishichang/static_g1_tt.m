function T = static_g1_tt(T, y, x, params)
% function T = static_g1_tt(T, y, x, params)
%
% File created by Dynare Preprocessor from .mod file
%
% Inputs:
%   T         [#temp variables by 1]  double   vector of temporary terms to be filled by function
%   y         [M_.endo_nbr by 1]      double   vector of endogenous variables in declaration order
%   x         [M_.exo_nbr by 1]       double   vector of exogenous variables in declaration order
%   params    [M_.param_nbr by 1]     double   vector of parameter values in declaration order
%
% Output:
%   T         [#temp variables by 1]  double   vector of temporary terms
%

assert(length(T) >= 76);

T = nov1119tongyishichang.static_resid_tt(T, y, x, params);

T(55) = (1-params(5))*T(2)*exp(y(1))*getPowerDeriv(exp(y(1)),(-params(10)),1);
T(56) = (1-params(5))*T(7)*exp(y(2))*getPowerDeriv(exp(y(2)),(-params(10)),1);
T(57) = (1-params(5))*T(1)*exp(y(3))*getPowerDeriv(exp(y(3)),params(4)*(1-params(10)),1);
T(58) = (1-params(5))*T(6)*exp(y(4))*getPowerDeriv(exp(y(4)),params(4)*(1-params(10)),1);
T(59) = getPowerDeriv(T(11),params(14)-1,1);
T(60) = getPowerDeriv(T(12),params(14)-1,1);
T(61) = getPowerDeriv(T(14),params(14)-1,1);
T(62) = getPowerDeriv(T(15),params(14)-1,1);
T(63) = getPowerDeriv(T(9),T(10),1);
T(64) = getPowerDeriv(T(13),T(10),1);
T(65) = getPowerDeriv(T(18),params(28)-1,1);
T(66) = getPowerDeriv(T(20),params(28)-1,1);
T(67) = getPowerDeriv(T(23),params(28)-1,1);
T(68) = getPowerDeriv(T(25),params(28)-1,1);
T(69) = (-(exp(y(3))*params(17)*exp(y(42)*params(17))))/(exp(y(42)*params(17))*exp(y(42)*params(17)))/(exp(y(3))/exp(y(42)*params(17)));
T(70) = (-(exp(y(35))*exp(y(42)+log(params(16)))))/(exp(y(42)+log(params(16)))*exp(y(42)+log(params(16))))/(exp(y(35))/exp(y(42)+log(params(16))));
T(71) = (-(exp(y(4))*params(17)*exp(y(43)*params(17))))/(exp(y(43)*params(17))*exp(y(43)*params(17)))/(exp(y(4))/exp(y(43)*params(17)));
T(72) = (-(exp(y(36))*exp(y(43)+log(params(16)))))/(exp(y(43)+log(params(16)))*exp(y(43)+log(params(16))))/(exp(y(36))/exp(y(43)+log(params(16))));
T(73) = (-(exp(y(44))*exp(y(52))*params(21)*params(18)/exp(y(19))));
T(74) = (-(exp(y(45))*exp(y(53))*params(23)*params(19)/exp(y(20))));
T(75) = getPowerDeriv(T(16),T(17),1);
T(76) = getPowerDeriv(T(22),T(17),1);

end
