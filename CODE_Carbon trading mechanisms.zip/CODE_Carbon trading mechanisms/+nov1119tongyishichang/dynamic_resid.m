function residual = dynamic_resid(T, y, x, params, steady_state, it_, T_flag)
% function residual = dynamic_resid(T, y, x, params, steady_state, it_, T_flag)
%
% File created by Dynare Preprocessor from .mod file
%
% Inputs:
%   T             [#temp variables by 1]     double   vector of temporary terms to be filled by function
%   y             [#dynamic variables by 1]  double   vector of endogenous variables in the order stored
%                                                     in M_.lead_lag_incidence; see the Manual
%   x             [nperiods by M_.exo_nbr]   double   matrix of exogenous variables (in declaration order)
%                                                     for all simulation periods
%   steady_state  [M_.endo_nbr by 1]         double   vector of steady state values
%   params        [M_.param_nbr by 1]        double   vector of parameter values in declaration order
%   it_           scalar                     double   time period for exogenous variables for which
%                                                     to evaluate the model
%   T_flag        boolean                    boolean  flag saying whether or not to calculate temporary terms
%
% Output:
%   residual
%

if T_flag
    T = nov1119tongyishichang.dynamic_resid_tt(T, y, x, params, steady_state, it_);
end
residual = zeros(61, 1);
lhs = exp(y(20));
rhs = params(6)/T(4);
residual(1) = lhs - rhs;
lhs = exp(y(22));
rhs = params(7)/T(4);
residual(2) = lhs - rhs;
lhs = exp(y(24));
rhs = (T(8)-(1-params(12)))/(1-params(5));
residual(3) = lhs - rhs;
lhs = exp(y(28));
rhs = (T(8)-(1-params(11)))/(1-params(5));
residual(4) = lhs - rhs;
lhs = exp(y(26));
rhs = (1-params(12))*exp(y(3))+y(32);
residual(5) = lhs - rhs;
lhs = exp(y(30));
rhs = (1-params(11))*exp(y(5))+y(34);
residual(6) = lhs - rhs;
lhs = exp(y(21));
rhs = params(8)/T(12);
residual(7) = lhs - rhs;
lhs = exp(y(23));
rhs = params(9)/T(12);
residual(8) = lhs - rhs;
lhs = exp(y(25));
rhs = (T(16)-(1-params(12)))/(1-params(5));
residual(9) = lhs - rhs;
lhs = exp(y(29));
rhs = (T(16)-(1-params(11)))/(1-params(5));
residual(10) = lhs - rhs;
lhs = exp(y(27));
rhs = (1-params(12))*exp(y(4))+exp(y(33));
residual(11) = lhs - rhs;
lhs = exp(y(31));
rhs = (1-params(11))*exp(y(6))+exp(y(35));
residual(12) = lhs - rhs;
lhs = exp(y(36));
rhs = T(17)^T(18);
residual(13) = lhs - rhs;
lhs = exp(y(42));
rhs = params(13)*T(19)^(params(14)-1);
residual(14) = lhs - rhs;
lhs = exp(y(43));
rhs = (1-params(13))*T(20)^(params(14)-1);
residual(15) = lhs - rhs;
lhs = exp(y(37));
rhs = T(21)^T(18);
residual(16) = lhs - rhs;
lhs = exp(y(42));
rhs = (1-params(13))*T(22)^(params(14)-1);
residual(17) = lhs - rhs;
lhs = exp(y(43));
rhs = params(13)*T(23)^(params(14)-1);
residual(18) = lhs - rhs;
lhs = exp(y(48));
rhs = T(24)^T(25);
residual(19) = lhs - rhs;
lhs = exp(y(63));
rhs = T(27);
residual(20) = lhs - rhs;
lhs = exp(y(64));
rhs = T(29);
residual(21) = lhs - rhs;
lhs = exp(y(49));
rhs = T(30)^T(25);
residual(22) = lhs - rhs;
lhs = exp(y(63));
rhs = T(32);
residual(23) = lhs - rhs;
lhs = exp(y(64));
rhs = T(34);
residual(24) = lhs - rhs;
lhs = exp(y(44));
rhs = T(41)*T(42);
residual(25) = lhs - rhs;
lhs = exp(y(24));
rhs = exp(y(44))*exp(y(42))*params(20)/exp(y(26));
residual(26) = lhs - rhs;
lhs = exp(y(20));
rhs = T(43);
residual(27) = lhs - rhs;
lhs = exp(y(50));
rhs = exp(y(44))*exp(y(42))*params(2)/exp(y(48));
residual(28) = lhs - rhs;
lhs = exp(y(55));
rhs = T(45)*T(46);
residual(29) = lhs - rhs;
lhs = exp(y(57));
rhs = exp(y(55))*params(18);
residual(30) = lhs - rhs;
lhs = exp(y(28));
rhs = exp(y(55))*exp(y(63))*params(21)*params(18)/exp(y(30));
residual(31) = lhs - rhs;
lhs = exp(y(22));
rhs = T(47);
residual(32) = lhs - rhs;
lhs = exp(y(45));
rhs = T(54)*T(55);
residual(33) = lhs - rhs;
lhs = exp(y(25));
rhs = exp(y(45))*exp(y(43))*params(22)/exp(y(27));
residual(34) = lhs - rhs;
lhs = exp(y(21));
rhs = T(56);
residual(35) = lhs - rhs;
lhs = exp(y(51));
rhs = exp(y(45))*exp(y(43))*params(3)/exp(y(49));
residual(36) = lhs - rhs;
lhs = exp(y(56));
rhs = T(58)*T(59);
residual(37) = lhs - rhs;
lhs = exp(y(58));
rhs = exp(y(56))*params(19);
residual(38) = lhs - rhs;
lhs = exp(y(29));
rhs = exp(y(56))*exp(y(64))*params(23)*params(19)/exp(y(31));
residual(39) = lhs - rhs;
lhs = exp(y(23));
rhs = T(60);
residual(40) = lhs - rhs;
lhs = exp(y(53));
rhs = exp(y(14))+exp(y(46))+exp(y(12))+exp(y(32))+exp(y(34))+exp(y(42))*exp(y(39))-exp(y(40))*exp(y(43));
residual(41) = lhs - rhs;
lhs = exp(y(53));
rhs = exp(y(42))*exp(y(44));
residual(42) = lhs - rhs;
lhs = exp(y(44));
rhs = exp(y(38))+exp(y(39));
residual(43) = lhs - rhs;
lhs = exp(y(54));
rhs = exp(y(40))*exp(y(43))+exp(y(15))+exp(y(47))+exp(y(35))+exp(y(13))+exp(y(33))-exp(y(42))*exp(y(39));
residual(44) = lhs - rhs;
lhs = exp(y(54));
rhs = exp(y(43))*exp(y(45));
residual(45) = lhs - rhs;
lhs = exp(y(45));
rhs = exp(y(40))+exp(y(41));
residual(46) = lhs - rhs;
lhs = exp(y(57));
rhs = exp(y(59))+exp(y(60));
residual(47) = lhs - rhs;
lhs = exp(y(58));
rhs = exp(y(61))+exp(y(62));
residual(48) = lhs - rhs;
lhs = log(y(52));
rhs = params(30)*log(y(9))+x(it_, 1);
residual(49) = lhs - rhs;
lhs = log(exp(y(14))/exp(y(53)*params(17)));
rhs = params(33)*log(exp(y(1))/exp(params(17)*y(10)))+x(it_, 4);
residual(50) = lhs - rhs;
lhs = log(exp(y(15))/exp(y(54)*params(17)));
rhs = params(34)*log(exp(y(2))/exp(params(17)*y(11)))+x(it_, 5);
residual(51) = lhs - rhs;
lhs = log(exp(y(46))/exp(y(53)+log(params(16))));
rhs = params(31)*log(exp(y(7))/exp(y(10)+log(params(16))))-params(26)*(min(y(53)-y(54),0)+max(y(48)-y(49),0))+params(27)*(max(y(53)-y(54),0)+min(y(48)-y(49),0))+x(it_, 2);
residual(52) = lhs - rhs;
lhs = log(exp(y(47))/exp(y(54)+log(params(16))));
rhs = params(32)*log(exp(y(8))/exp(y(11)+log(params(16))))-params(26)*(min(y(54)-y(53),0)+max(y(49)-y(48),0))+params(27)*(max(y(54)-y(53),0)+min(y(49)-y(48),0))+x(it_, 3);
residual(53) = lhs - rhs;
lhs = exp(y(65));
rhs = exp(y(53))+exp(y(54));
residual(54) = lhs - rhs;
lhs = exp(y(67));
rhs = exp(y(32))+exp(y(34));
residual(55) = lhs - rhs;
lhs = exp(y(68));
rhs = exp(y(33))+exp(y(35));
residual(56) = lhs - rhs;
lhs = exp(y(66));
rhs = exp(y(35))+exp(y(33))+exp(y(32))+exp(y(34));
residual(57) = lhs - rhs;
lhs = exp(y(69));
rhs = exp(y(12))+exp(y(13));
residual(58) = lhs - rhs;
lhs = exp(y(71));
rhs = exp(y(48))*(1/params(24)-1);
residual(59) = lhs - rhs;
lhs = exp(y(72));
rhs = exp(y(49))*(1/params(25)-1);
residual(60) = lhs - rhs;
lhs = exp(y(70));
rhs = exp(y(71))+exp(y(72));
residual(61) = lhs - rhs;

end
