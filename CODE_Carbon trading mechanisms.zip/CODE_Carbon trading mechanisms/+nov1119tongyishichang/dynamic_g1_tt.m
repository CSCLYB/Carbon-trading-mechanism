function T = dynamic_g1_tt(T, y, x, params, steady_state, it_)
% function T = dynamic_g1_tt(T, y, x, params, steady_state, it_)
%
% File created by Dynare Preprocessor from .mod file
%
% Inputs:
%   T             [#temp variables by 1]     double  vector of temporary terms to be filled by function
%   y             [#dynamic variables by 1]  double  vector of endogenous variables in the order stored
%                                                    in M_.lead_lag_incidence; see the Manual
%   x             [nperiods by M_.exo_nbr]   double  matrix of exogenous variables (in declaration order)
%                                                    for all simulation periods
%   steady_state  [M_.endo_nbr by 1]         double  vector of steady state values
%   params        [M_.param_nbr by 1]        double  vector of parameter values in declaration order
%   it_           scalar                     double  time period for exogenous variables for which
%                                                    to evaluate the model
%
% Output:
%   T           [#temp variables by 1]       double  vector of temporary terms
%

assert(length(T) >= 90);

T = nov1119tongyishichang.dynamic_resid_tt(T, y, x, params, steady_state, it_);

T(61) = T(2)*exp(y(12))*getPowerDeriv(exp(y(12)),(-params(10)),1);
T(62) = (1-params(5))*T(61);
T(63) = (-(T(61)/T(7)/params(1)/(1-params(5))));
T(64) = (-((-(T(3)*T(6)*exp(y(73))*getPowerDeriv(exp(y(73)),(-params(10)),1)))/(T(7)*T(7))/params(1)/(1-params(5))));
T(65) = T(10)*exp(y(13))*getPowerDeriv(exp(y(13)),(-params(10)),1);
T(66) = (1-params(5))*T(65);
T(67) = (-(T(65)/T(15)/params(1)/(1-params(5))));
T(68) = (-((-(T(11)*T(14)*exp(y(74))*getPowerDeriv(exp(y(74)),(-params(10)),1)))/(T(15)*T(15))/params(1)/(1-params(5))));
T(69) = T(1)*exp(y(14))*getPowerDeriv(exp(y(14)),params(4)*(1-params(10)),1);
T(70) = (1-params(5))*T(69);
T(71) = (-(T(69)/T(7)/params(1)/(1-params(5))));
T(72) = (-((-(T(3)*T(5)*exp(y(75))*getPowerDeriv(exp(y(75)),params(4)*(1-params(10)),1)))/(T(7)*T(7))/params(1)/(1-params(5))));
T(73) = T(9)*exp(y(15))*getPowerDeriv(exp(y(15)),params(4)*(1-params(10)),1);
T(74) = (1-params(5))*T(73);
T(75) = (-(T(73)/T(15)/params(1)/(1-params(5))));
T(76) = (-((-(T(11)*T(13)*exp(y(76))*getPowerDeriv(exp(y(76)),params(4)*(1-params(10)),1)))/(T(15)*T(15))/params(1)/(1-params(5))));
T(77) = getPowerDeriv(T(19),params(14)-1,1);
T(78) = getPowerDeriv(T(20),params(14)-1,1);
T(79) = getPowerDeriv(T(22),params(14)-1,1);
T(80) = getPowerDeriv(T(23),params(14)-1,1);
T(81) = getPowerDeriv(T(17),T(18),1);
T(82) = getPowerDeriv(T(21),T(18),1);
T(83) = getPowerDeriv(T(26),params(28)-1,1);
T(84) = getPowerDeriv(T(28),params(28)-1,1);
T(85) = getPowerDeriv(T(31),params(28)-1,1);
T(86) = getPowerDeriv(T(33),params(28)-1,1);
T(87) = (-(exp(y(55))*exp(y(63))*params(21)*params(18)/exp(y(30))));
T(88) = (-(exp(y(56))*exp(y(64))*params(23)*params(19)/exp(y(31))));
T(89) = getPowerDeriv(T(24),T(25),1);
T(90) = getPowerDeriv(T(30),T(25),1);

end
